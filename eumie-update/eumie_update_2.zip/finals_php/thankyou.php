<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You - Gachaddict</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
        <header>
            <h1>Order Complete</h1>
            <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            </nav>
        </header>

<main class="container">
    <h2 style="text-align: center; margin-top: 40px;">🎉 Thank you for your purchase!</h2>
    <p style="text-align: center;">Your order has been placed successfully.</p>
  </main>
  <footer>
  <p>&copy; <?= date('Y') ?> Gachaddict. All rights reserved.</p>
  </footer>
</body>
</html>
