<?php
session_start();

// Handle Add to Cart submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['name'];
    $product_price = floatval($_POST['price']);
    $product_quantity = intval($_POST['quantity']);

    // If item already exists in cart, update quantity
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['quantity'] += $product_quantity;
    } else {
        // Add new item
        $_SESSION['cart'][$product_id] = [
            'name' => $product_name,
            'price' => $product_price,
            'quantity' => $product_quantity
        ];
    }

    // Optional: Redirect to avoid resubmission
    header("Location: cart.php");
    exit;
}


?>
