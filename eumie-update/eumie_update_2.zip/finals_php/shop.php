<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🃏Gachaddict</title>
  <link rel="stylesheet" href="style_shop.css">
</head>
<body>
  <header>
    <h1>Shop</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="cart.php">Cart</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main class="container">

    <!-- BEST SELLERS -->
    <h2>Best Sellers</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++): 
        $name = "Popular Card " . ($i + 1);
        $price = 90 + $i * 5;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Best selling card from our collection.</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
 <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Pokémon Cards -->
    <h2>Pokémon Cards</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++):
        $name = "Pokémon " . ($i + 1);
        $price = 60 + $i * 3;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Catch 'em all – special edition cards!</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
           <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Magic: The Gathering -->
    <h2>Magic: The Gathering</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++):
        $name = "Magic Card " . ($i + 1);
        $price = 75 + $i * 4 + 0.50;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Strategic gameplay cards from MTG.</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
            <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Cookie Run -->
    <h2>Cookie Run Cards</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++):
        $name = "Cookie Card " . ($i + 1);
        $price = 40 + $i * 2 + 0.99;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Cute collectible cards from Cookie Run.</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
            <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>

          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Card Wars -->
    <h2>Card Wars</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++):
        $name = "Card Wars " . ($i + 1);
        $price = 35 + $i * 3.00;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Adventure Time inspired battle cards.</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
              <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>

          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

    <!-- Lorcana -->
    <h2>Lorcana Cards</h2>
    <div class="product-grid">
      <?php for ($i = 0; $i < 4; $i++):
        $name = "Lorcana " . ($i + 1);
        $price = 55 + $i * 5 + 0.75;
      ?>
      <div class="card">
        <div class="card-img"><div class="img"></div></div>
        <div class="card-title"><?= $name ?></div>
        <div class="card-subtitle">Fantasy realm cards for collectors.</div>
        <hr class="card-divider">
        <div class="card-footer">
          <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
          <form method="POST" action="cart.php">
            <input type="hidden" name="product_id" value="<?= $i ?>">
            <input type="hidden" name="name" value="<?= $name ?>">
            <input type="hidden" name="price" value="<?= $price ?>">
            <input type="hidden" name="quantity" value="1">
            <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
          </form>
        </div>
      </div>
      <?php endfor; ?>
    </div>

  </main>

  <footer>
    <p>&copy; <?= date('Y') ?> Gachaddict. All rights reserved.</p>
  </footer>
</body>
</html>
