<?php
$cards = [
  ["title" => "Obsidian Flames Pokemon TCG", "price" => 14.99, "color" => "142, 249, 252", "image" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcVW09f5o3TeMM-_NR-dQmnCFoeK-Ic62sxw&s"],
  ["title" => "Green Starter CRK TCG", "price" => 9.99, "color" => "142, 252, 204", "image" => "https://cookierunbraverse.com/storage/pack/d4ebc305ba5e9feff393c74307165e79.png.webp"],
  ["title" => "Purple Starter CRK TCG", "price" => 9.99, "color" => "142, 252, 157", "image" => "https://cookierunbraverse.com/storage/pack/9675f186024e9a4572a1e2676af5fb36.png.webp"],
  ["title" => "MTG 2019 core set", "price" => 24.99, "color" => "215, 252, 142", "image" => "https://m.media-amazon.com/images/I/81CIm+qYyTL.jpg"],
  ["title" => "Lorcana Shimmering Skies", "price" => 19.99, "color" => "252, 252, 142", "image" => "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDmoBcPdPWn-gZAeZquvNB4SiR5uOfPF33xOoQVvv0XDYOEHOYk0IUiENsPNyod9R6JCY&usqp=CAU"],
  ["title" => "Lorcana Ursula's Return", "price" => 21.99, "color" => "252, 208, 142", "image" => "https://cdn.webshopapp.com/shops/352022/files/460823055/650x750x2/disney-lorcana-ursulas-return-starter-deck-anna-he.jpg"],
  ["title" => "Card Wars Collectors Edition", "price" => 29.99, "color" => "252, 142, 142", "image" => "https://cf.geekdo-images.com/3W7eBmij7f0jCWV91JNOPQ__itemrep/img/sF1DABRr4bq65lEfqOlmIj-sn6k=/fit-in/246x300/filters:strip_icc()/pic2904522.jpg"],
  ["title" => "Card Wars Hero Pack #1", "price" => 11.99, "color" => "252, 142, 239", "image" => "https://m.media-amazon.com/images/I/81vHZA+wiYL._AC_UF894,1000_QL80_.jpg"],
  ["title" => "151 Pokemon TCG", "price" => 17.99, "color" => "204, 142, 252", "image" => "https://wafuu.com/cdn/shop/products/pokemon-card-game-scarlett-violet-enhanced-expansion-pack-151-booster-293159_540x.jpg?v=1695256281"],
  ["title" => "Journey Together Pokemon TCG", "price" => 15.49, "color" => "142, 202, 252", "image" => "https://http2.mlstatic.com/D_NQ_NP_920249-MLA83087467886_032025-O.webp"],
];
?>
<!-- Begin HTML Output -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🃏Gachaddict</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Welcome to Gachaddict</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="Cart.php">Cart</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>
  <main class="container">
    <div>
      <h1>BEST SELLERS</h1>
    </div>
   <div class="wrapper">
  <div class="inner" style="--quantity: <?= count($cards) ?>;">
    <?php foreach ($cards as $index => $card): ?>
      <div class="card" 
           style="--index: <?= $index ?>; --color-card: <?= $card['color'] ?>;"
           data-product-id="<?= $index ?>"
           data-name="<?= htmlspecialchars($card['title']) ?>"
           data-price="<?= $card['price'] ?>">
        <div class="img" style="background-image: url('<?= $card['image'] ?>');">
          <div class="overlay">
            <h4><?= htmlspecialchars($card['title']) ?></h4>
            <p>$<?= number_format($card['price'], 2) ?></p>
            <button type="button" class="card-btn" onclick="addToCart(this)">Buy</button>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Hidden form used for add to cart -->
<form id="hiddenCartForm" action="cart.php" method="POST" style="display: none;">
  <input type="hidden" name="product_id">
  <input type="hidden" name="name">
  <input type="hidden" name="price">
  <input type="hidden" name="quantity" value="1">
  <input type="hidden" name="add_to_cart" value="1">
</form>

    <?php include "index.html"; ?>
  </main>
  <footer>
    <p>&copy; <?= date('Y') ?> Gachaddict. All rights reserved.</p>
  </footer>
</body>
<script>
function addToCart(button) {
  const card = button.closest('.card');
  const form = document.getElementById('hiddenCartForm');

  form.product_id.value = card.dataset.productId;
  form.name.value = card.dataset.name;
  form.price.value = card.dataset.price;

  form.submit();
}
</script>

</html>
