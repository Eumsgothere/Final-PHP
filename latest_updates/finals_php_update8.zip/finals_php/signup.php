<?php
// Redirect to login.php after successful signup
header("Location: login.php");
exit();
?>