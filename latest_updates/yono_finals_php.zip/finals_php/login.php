<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
  <style>
  .container {
    padding: 80px 20px 40px 20px;
  }

  .wrapper {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    gap: 40px;
    flex-wrap: wrap;
    margin-top: 20px;
  }

  .contact-info, .contact-form {
    width: 100%;
    max-width: 400px;
    background: #fff;
    padding: 24px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }


      .contact-info h2, .contact-form .title {
        margin-bottom: 16px;
      }

      .form {
        display: flex;
        flex-direction: column;
      }

      .input, textarea {
        margin-bottom: 16px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 16px;
      }

      textarea {
        resize: vertical;
        height: 120px;
      }

      button {
        padding: 12px;
        background-color: #ADD8E6;
        color: #fff;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
      }

      button:hover {
        background-color: #ADD8E6;
      }
  </style>
</head>
<body>
  <header>
    <h1>Login</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="Cart.php">Cart</a>
      <a href="contact.php">Contact</a>
      <a href="login.php">Login</a>
    </nav>
  </header>
  <main class="container">
    <div class="wrapper">
      <section class="contact-form">
        <div class="title">Sign In</div>
        <form class="form" action="login_process.php" method="POST">
          <input type="email" name="email" placeholder="Email" class="input" required>
          <input type="password" name="password" placeholder="Password" class="input" required>
          <button type="submit">Sign In</button>
          <div style="margin-top: 12px;">
        <label>
          <input type="checkbox" name="remember"> Remember me</label>
          </div>
        </form>
        <div style="margin: 24px 0 12px 0; text-align: center;">

        <div style="margin-top: 24px; text-align: center;">
          Don't have an account? <a href="#" onclick="document.getElementById('signup-box').style.display='block';document.getElementById('signin-box').style.display='none';return false;">Sign up</a>
        </div>
      </section>

      <section class="contact-form" id="signup-box" style="display:none;">
        <div class="title">Sign Up</div>
        <form class="form" action="signup_process.php" method="POST">
          <input type="text" name="name" placeholder="Name" class="input" required>
          <input type="email" name="email" placeholder="Email" class="input" required>
          <input type="password" name="password" placeholder="Password" class="input" required>
          <input type="password" name="confirm_password" placeholder="Confirm Password" class="input" required>
          <button type="submit">Sign Up</button>
        </form>
        <div style="margin-top: 24px; text-align: center;">
          Already have an account? <a href="#" onclick="document.getElementById('signup-box').style.display='none';document.getElementById('signin-box').style.display='block';return false;">Sign in</a>
        </div>
      </section>
      <script>
        // Show sign in by default
        document.querySelector('.contact-form').setAttribute('id', 'signin-box');
      </script>

    </div>
  </main>

  <footer>
    <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
  </footer>
</body>
</html>
