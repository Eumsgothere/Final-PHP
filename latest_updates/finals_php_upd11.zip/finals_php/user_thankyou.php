<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You - CARDIAC</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
        <header>
            <h1>Order Complete</h1>
            <nav>
            <a href="user_page.php">Home</a>
            <a href="user_shop.php">Shop</a>
            </nav>
        </header>

<main class="container">
    <h2 style="text-align: center; margin-top: 40px;">🎉 Thank you for your purchase!</h2>
    <p style="text-align: center;">Your order has been placed successfully.</p>
    </main>
    <footer>
         <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
    </footer>
</body>
</html>
