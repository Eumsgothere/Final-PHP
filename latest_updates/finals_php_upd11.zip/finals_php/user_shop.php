<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🃏CARDIAC</title>
  <link rel="stylesheet" href="user_style_shop.css">
</head>
<body>
  <header>
    <h1>Shop</h1>
    <nav>
      <a href="user_page.php">Home</a>
      <a href="user_shop.php">Shop</a>
      <a href="user_cart.php">Cart</a>
      <a href="user_contact.php">Contact</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main class="container">

<!-- BEST SELLERS -->
<h2>Best Sellers</h2>
<div class="product-grid">
<?php
$images = [
  "https://assets.pokemon.com/static-assets/content-assets/cms2/img/cards/web/SV10/SV10_EN_232.png",
  "https://assets.pokemon.com/assets/cms2/img/cards/web/XY12/XY12_EN_12.png",
  "https://assets.pokemon.com/static-assets/content-assets/cms2/img/cards/web/SV8PT5/SV8PT5_EN_161.png",
  "https://www.pokemon.com/static-assets/content-assets/cms2/img/cards/web/SM5/SM5_EN_90.png"
];

$names = [
  "Cynthia’s Garchomp EX (Scarlet & Violet—Destined Rivals)",
  "Charizard EX (XY—Flashfire)",
  "Umbreon EX (Prismatic Evolutions)",
  "Dusk Mane Necrozma-GX (Ultra Prism)"
];

for ($i = 0; $i < 4; $i++):
  $name = $names[$i];
  $price = 90 + $i * 5;
  $image = $images[$i];
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Best selling card from our collection.</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

<!-- Pokémon Packs -->
<h2>Pokémon Packs</h2>
<div class="product-grid">
<?php
$pokemonImages = [
  "https://m.media-amazon.com/images/I/717kShcxzDL.jpg",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDCtshnWfNgfuJ_6IHFWYUJaOgUlTCiG4paQ&s",
  "https://eclipsecards.com/cdn/shop/products/PokemonTCG_Sword_Shield-FusionStrikeBoosterPack-Mew_a9ff804d-50cf-4dc0-913b-db2bb53568e6.png?v=1646786695",
  "https://eternacards.co.uk/cdn/shop/files/pokemon-tcg-scarlet-violet-base-set-booster-pack-877092_700x700.webp?v=1719348557"
];

$pokemonNames = [
  "Scarlet & Violet—151",
  "Sword & Shield Brilliant Stars",
  "Sword & Shield Fusion Strike",
  "Scarlet & Violet Base" 
];

for ($i = 0; $i < 4; $i++):
  $name = $pokemonNames[$i];
  $price = 60 + $i * 3;
  $image = $pokemonImages[$i];
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Catch 'em all – special edition cards!</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

<!-- Magic: The Gathering -->
<h2>Magic: The Gathering</h2>
<div class="product-grid">
<?php
$magicImages = [
  "https://api.scryfall.com/cards/pdom/207s?format=image&version=normal",
  "https://api.scryfall.com/cards/m21/282?format=image&version=normal",
  "https://gatherer.wizards.com/Handlers/Image.ashx?multiverseid=555212&type=cardg",
  "https://gatherer-static.wizards.com/Cards/medium/E5E765693CF6B0E81CEAA25157BA6CF5B9DD904D0A2EE81DAB577416BFE92539.webp"
];

$magicNames = [
  "Teferi, Hero of Dominaria",
  "Liliana, Waker of the Dead",
  "Elspeth Resplendent",
  "Ajani, Strength of the Pride"
];

for ($i = 0; $i < 4; $i++):
  $name = $magicNames[$i];
  $image = $magicImages[$i];
  $price = 75 + $i * 4 + 0.50;
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Strategic gameplay cards from MTG.</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

<!-- Cookie Run -->
<h2>Cookie Run Cards</h2>
<div class="product-grid">
<?php
$cookieRunImages = [
  "https://cookierunbraverse.com/storage/notice/24a2429abfb3a57568e1f6fcf1e1e19c.png.webp?v=20250626110800",
  "https://cookierunbraverse.com/storage/notice/aff16b63ecd11779c5fa8cbd1ca4bae6.png.webp?v=20250626110800",
  "https://cookierunbraverse.com/storage/notice/f32e347a8389ff4db57a21746ec0c784.png.webp?v=20250626110800",
  "https://cookierunbraverse.com/storage/notice/a763cd0034019c09e9e0291e21b45124.png.webp?v=20250619095452"
];
$cookieRunNames = [
  "Age of Heroes and Kingdoms",
  "Brave Beginning",
  "Operation Timeguard",
  "CookieRun Card Game Starter Deck Purple"
];

for ($i = 0; $i < 4; $i++):
  $name = $cookieRunNames[$i];
  $price = 40 + $i * 2 + 0.99;
  $image = $cookieRunImages[$i];
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Cute collectible cards from Cookie Run.</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

<!-- Card Wars -->
<h2>Card Wars</h2>
<div class="product-grid">
<?php
$cardWarsImages = [
   "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTDtw1fKBf7qs38TuhvT3qAIH5D9TXZi4sdpA&s",
  "https://cf.geekdo-images.com/NeUOhHhGlHTrdWinnCKs8Q__itemrep/img/A33sHNOkmiCej57bHqW6e93W8dM=/fit-in/246x300/filters:strip_icc()/pic1919612.jpg",
  "https://cf.geekdo-images.com/8jLOcZ9f3VRYwbf1c5v13w__itemrep/img/qIJqbbgPGk8iEUzHApGvotUaDAw=/fit-in/246x300/filters:strip_icc()/pic2453921.jpg",
  "https://cf.geekdo-images.com/R6YCdclwD--5KP6L0vX9_g__itemrep/img/3BChBk_44YtTsUjtKIYysNEzaUo=/fit-in/246x300/filters:strip_icc()/pic2200365.jpg"
];

$cardWarsNames = [
  "Finn vs Jake Deck",
  "BMO vs Lady Rainicorn Deck",
  "Ice King vs Marceline Deck",
  "Princess Bubblegum vs Lumpy Space Princess Deck"
];

for ($i = 0; $i < 4; $i++):
  $name = $cardWarsNames[$i];
  $price = 35 + $i * 3.00;
  $image = $cardWarsImages[$i];
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Adventure Time inspired battle cards.</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

<!-- Lorcana -->
<h2>Lorcana Cards</h2>
<div class="product-grid">
<?php
$lorcanaImages = [
   "https://eternacards.co.uk/cdn/shop/files/disney-lorcana-archazias-island-booster-pack-816167.webp?v=1741973007",
  "https://thecardvault.co.uk/cdn/shop/files/Disney_Lorcana_Fabled_Booster-Pack_Cruella.png?v=1750667686&width=645",
  "https://cdn.cardsrealm.com/images/cartas/1-the-first-chapter/EN/med/disney-lorcana-the-first-chapter-booster-pack-.png?8433?&width=250",
  "https://www.beaniegames.co.uk/images/disney-lorcana-set-5-shimmering-skies-booster-pack-p16922-16726_image.jpg"
];

$lorcanaNames = [
  "Archazia's Island",
  "Fabled",
  "The First Chapter",
  "Shimmering Skies"
];

for ($i = 0; $i < 4; $i++):
  $name = $lorcanaNames[$i];
  $price = 55 + $i * 5 + 0.75;
  $image = $lorcanaImages[$i];
?>
  <div class="card">
    <div class="card-img">
      <img src="<?= $image ?>" alt="<?= $name ?>">
    </div>
    <div class="card-title"><?= $name ?></div>
    <div class="card-subtitle">Fantasy realm cards for collectors.</div>
    <hr class="card-divider">
    <div class="card-footer">
      <div class="card-price"><span>$</span> <?= number_format($price, 2) ?></div>
      <form method="POST" action="user_cart.php">
        <input type="hidden" name="product_id" value="<?= $i ?>">
        <input type="hidden" name="name" value="<?= $name ?>">
        <input type="hidden" name="price" value="<?= $price ?>">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" name="add_to_cart" class="card-btn">Add to Cart</button>
      </form>
    </div>
  </div>
<?php endfor; ?>
</div>

</main>

<footer>
  <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
</footer>
</body>
</html>
