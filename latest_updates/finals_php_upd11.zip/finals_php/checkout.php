<?php
session_start();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$discount = $_SESSION['discount'] ?? 0;
$discount_amount = $subtotal * $discount;
$shipping = 4.99;
$total = $subtotal - $discount_amount + $shipping;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['name'] ?? '';
    $address = $_POST['address'] ?? '';
    $email = $_POST['email'] ?? '';
    $payment = $_POST['payment'] ?? '';

    if ($name && $address && $email && $payment) {

        $_SESSION['cart'] = [];
        $_SESSION['discount'] = 0;
        $_SESSION['coupon_code'] = '';
        header('Location: thankyou.php');
        exit;
    } else {
        $error = "Please fill in all required fields.";
    }
}

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    $_SESSION['login_error'] = "You must be logged in to checkout.";
    $_SESSION['active_form'] = 'login';
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout - CARDIAC</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .checkout-container {
      max-width: 600px;
      margin: 40px auto;
      background: rgba(255,255,255,0.9);
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .checkout-container h2 {
      text-align: center;
      margin-bottom: 20px;
    }
    .checkout-container form label {
      display: block;
      margin: 12px 0 5px;
      font-weight: bold;
    }
    .checkout-container form input,
    .checkout-container form select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
    }
    .checkout-summary {
      margin-top: 20px;
      font-size: 0.95rem;
    }
    .checkout-summary div {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }
    .checkout-container button {
      margin-top: 20px;
      width: 100%;
      background: #ADD8E6;
      color: black;
      padding: 12px;
      border: none;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
    }
    .error {
      color: red;
      font-size: 0.9rem;
      text-align: center;
    }
  </style>
</head>
<body>
  <header>
    <h1>Checkout</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="cart.php">Cart</a>
    </nav>
  </header>
<main class="container">
  <main class="checkout-container">
    <h2>Shipping & Payment</h2>
    <?php if (isset($error)): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <label for="name">Full Name</label>
      <input type="text" name="name" id="name" required>

      <label for="address">Shipping Address</label>
      <input type="text" name="address" id="address" required>

      <label for="email">Email Address</label>
      <input type="email" name="email" id="email" required>

      <label for="payment">Payment Method</label>
      <select name="payment" id="payment" required>
        <option value="">Select Payment</option>
        <option value="gcash">GCash</option>
        <option value="credit">Credit Card</option>
        <option value="cod">Cash on Delivery</option>
      </select>

      <div class="checkout-summary">
        <div><span>Subtotal:</span><span>$<?= number_format($subtotal, 2) ?></span></div>
        <div><span>Discount:</span><span>$<?= number_format($discount_amount, 2) ?></span></div>
        <div><span>Shipping:</span><span>$<?= number_format($shipping, 2) ?></span></div>
        <div><strong>Total:</strong><strong>$<?= number_format($total, 2) ?></strong></div>
      </div>

      <button type="submit">Place Order</button>
    </form>
  </main>
    </main>
    <footer>
  <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
  </footer>
</body>
</html>
