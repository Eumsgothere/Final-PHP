<?php
session_start();

$errors = [
  'login' => $_SESSION['login_error'] ?? '',
  'register' => $_SESSION['register_error'] ?? '',
];
$active_form = $_SESSION['active_form'] ?? 'login';

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>$error</p>" : '';
}

function isActiveForm($form, $active_form) {
    return $active_form === $form ? 'active' : '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
  <style>

.container{
  margin: 0 15px;
}

.form-box{
  width: 100%;
  max-width: 450px;
  padding: 30px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  display: none;
}

.form-box.active{
  display: block;
}

h2{
  font-size: 34px;
  text-align: center;
  margin-bottom: 20px;
}

input, select{
  width: 95%;
  padding: 12px;
  background: #eee;
  border-radius: 6px;
  border: 1px solid #ccc;
  outline: none;
  font-size: 16px;
  color: #333;
  margin-bottom: 20px;
}

button{
  width: 100%;
  padding: 12px;
  background: #ADD8E6;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  font-size: 16px;
  color: #fff;
  font-weight: 20px;
  transition: 0.5;
}

button:hover{
  background: #87CEEB;
}

p{
  font-size: 14.5px;
  text-align: center;
  margin-bottom: 10px;
}

p a{
  color: #ADD8E6;
  text-decoration: none;
}

p a:hover{
    text-decoration: underline;
  }

.error-message {
  padding: 12px;
  background: #f8d7da;
  border: 6px;
  font-size: 16px;
  color: #a42834;
  text-allign: center;
  margin-bottom: 20px;
}

  </style>
</head>
<body>
  <header>
    <h1>Login</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="Cart.php">Cart</a>
      <a href="contact.php">Contact</a>
      <a href="login.php">Logout</a>
    </nav>
  </header>
<div class="container">
    <div class="form-box active" id="logout-form">
        <form action="logout_action.php" method="post">
            <h2>Logout</h2>
            <p>Are you sure you want to logout?</p>
            <button type="submit" name="confirm_logout">Logout</button>
            <p><a href="index.php">Cancel</a></p>
        </form>
    </div>
</div>

  <script src="script.js"></script>
  <footer>
    <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
  </footer>
</body>
</html>
