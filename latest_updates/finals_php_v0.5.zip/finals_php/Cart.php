<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'] ?? '';
    $name = $_POST['name'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 1);

    if ($product_id !== '') {
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$product_id] = [
                'name' => $name,
                'price' => $price,
                'quantity' => $quantity
            ];
        }
    }
}

if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][$_GET['remove']]);
}

$discount = 0;
$coupon_code = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_coupon'])) {
    $coupon_code = strtoupper(trim($_POST['coupon']));

    if ($coupon_code === 'NUGGET') {
        $_SESSION['discount'] = 0.15;
        $_SESSION['coupon_code'] = $coupon_code;
    } elseif ($coupon_code === 'VINCEHASAGYATT') {
        $_SESSION['discount'] = 0.50;
        $_SESSION['coupon_code'] = $coupon_code;
    } else {
        $_SESSION['discount'] = 0;
        $_SESSION['coupon_code'] = '';
    }
}

$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$discount_rate = $_SESSION['discount'] ?? 0;
$discount_amount = $subtotal * $discount_rate;
$shipping = 4.99;
$total = $subtotal - $discount_amount + $shipping;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🛒 Cart</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Cart</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="shop.php">Shop</a>
      <a href="cart.php">Cart</a>
      <a href="contact.php">Contact</a>
      <a href="login.php">Login</a>
    </nav>
  </header>
  <main class="container">
  <div class="cart-box centered">
    <h2>Your Cart</h2>

      <?php if (!empty($_SESSION['cart'])): ?>
        <?php foreach ($_SESSION['cart'] as $id => $item): ?>
          <div class="cart-item">
            <div class="cart-info">
              <strong><?= htmlspecialchars($item['name']) ?></strong><br>
              Qty: <?= $item['quantity'] ?>
            </div>
            <div class="cart-price">
              $<?= number_format($item['price'] * $item['quantity'], 2) ?>
              <a href="?remove=<?= urlencode($id) ?>" class="remove-btn">✕</a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>Your cart is empty.</p>
      <?php endif; ?>

      <form class="coupon-form" method="POST">
  <input type="text" name="coupon" placeholder="Coupon code">
  <button type="submit" name="apply_coupon">Apply</button>
</form>

<?php if (!empty($_SESSION['coupon_code'])): ?>
  <p style="color: lightgreen; font-weight: bold; margin-top: 5px;">
    ✅ Active Coupon: <strong><?= htmlspecialchars($_SESSION['coupon_code']) ?></strong> (<?= $_SESSION['discount'] * 100 ?>% off)
  </p>
<?php endif; ?>

      <div class="cart-summary">
      <div><span>Subtotal:</span><span>$<?= number_format($subtotal, 2) ?></span></div>
      <div><span>Discount:</span><span>$<?= number_format($discount_amount, 2) ?></span></div>
      <div><span>Shipping:</span><span>$<?= number_format($shipping, 2) ?></span></div>
      <div class="total"><span>Total:</span><span>$<?= number_format($total, 2) ?></span></div>
    </div>

      <a href="checkout.php" class="checkout-btn" style="text-align:center; display:block; text-decoration:none;">Proceed to Checkout</a>
    </div>
  </main>
  <footer>
    <p>&copy; <?= date('Y') ?> CARDIAC. All rights reserved.</p>
  </footer>
</body>
</html>